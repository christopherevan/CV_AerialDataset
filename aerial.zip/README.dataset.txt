# Aerial Airport > v1
https://universe.roboflow.com/object-detection/aerial-airport

Provided by Roboflow
License: Public Domain

# Overview

The GDIT Aerial Airport dataset consists of aerial images containing instances of parked airplanes. All plane types have been grouped into a single classification named "airplane". 


# Example Image

![Aerial View](https://i.imgur.com/wxqFNd9.png)

